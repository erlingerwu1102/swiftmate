// frontend_2/src/tests/integration/01_safety.spec.ts
import { describe, it, expect, beforeEach } from 'vitest'
import { testClient, resetSystem } from '../utils'

describe(' 安全接口集成测试 (Real Backend)', () => {
  // 修改：使用 beforeEach 确保每个用例开始前机器人都是闲置的
  beforeEach(async () => {
    await resetSystem()
  })

  it('I-01: 参数边界检测 - 超大范围应被拒绝', async () => {
    const res = await testClient.post('/dynamics/identification', {
      trajectory_range: 9999, 
      trajectory_speed: 20
    })
    
    // 现在路径对了，系统闲置了，后端会返回 400 (Bad Request) 而不是 423
    expect(res.status).toBe(400) 
  })
})