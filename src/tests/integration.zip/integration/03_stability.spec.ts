// @vitest-environment node
import { describe, it, expect, beforeAll, afterAll } from 'vitest'
import { testClient, sleep, resetSystem } from '../utils'

/**
 * 稳定性测试配置
 * 建议：调试时设为 10秒，CI/CD 环境可设为更长 (如 2小时)
 */
const TEST_DURATION_MS = 10 * 1000 

describe('⏳ 长时间稳定性测试 (Stability)', () => {
  
  // 测试前强制重置，清除之前的锁
  beforeAll(async () => {
    await resetSystem()
  })

  // 测试后清理
  afterAll(async () => {
    await resetSystem()
  })

  it(`I-05: 连续运行测试 (持续时间: ${TEST_DURATION_MS / 1000}s)`, async () => {
    const endTime = Date.now() + TEST_DURATION_MS
    let cycles = 0
    let errors: string[] = []

    console.log(`\n🚀 [Stability] 开始稳定性测试...`)

    while (Date.now() < endTime) {
      try {
        // 1. 发送启动指令 (对齐后端真实路径)
        // utils.ts 中的 baseURL 已包含 /api/v1
        const startRes = await testClient.post('/dynamics/identification', {
          trajectory_range: 15,
          trajectory_speed: 50
        })

        // [关键修复] 处理资源锁定 (423)
        // 如果后端正忙（可能上一个 stop 还没完全结束），不要报错，而是等待重试
        if (startRes.status === 423) {
          // console.warn('   [Busy] 后端资源锁定，等待 1s...')
          await sleep(1000)
          continue // 跳过本次循环，不计入 error
        }

        // 处理其他非 200 错误 (如参数错误 400)
        if (startRes.status !== 200) {
          throw new Error(`Start failed with status: ${startRes.status}`)
        }

        // 2. 模拟运行 (Success Case)
        // 既然启动成功了，就让它跑一会儿
        await sleep(1000)
        
        // 3. 发送停止指令
        const stopRes = await testClient.post('/dynamics/identification/stop')
        
        if (stopRes.status === 200) {
          cycles++
          // 每 2 次循环打印一次进度，避免日志刷屏
          if (cycles % 2 === 0) process.stdout.write(`[Cycle ${cycles}] `)
        } else {
           throw new Error(`Stop failed with status: ${stopRes.status}`)
        }

        // 4. 循环间隔缓冲：给后端状态机留出复位时间
        await sleep(800)

      } catch (e: any) {
        console.error(`\n❌ [Error] 第 ${cycles} 次循环异常:`, e.message)
        errors.push(`Cycle ${cycles}: ${e.message}`)
        
        // 遇到错误时尝试强力重置
        await resetSystem()
        await sleep(2000)
      }
    }

    console.log(`\n\n📊 [Stability] 测试总结:`)
    console.log(`- 总完成循环: ${cycles}`)
    console.log(`- 异常中断数: ${errors.length}`)

    // 断言：
    // 1. 过程中无未捕获的逻辑错误
    expect(errors.length).toBe(0)
    // 2. 至少成功执行了一次完整闭环 (证明 423 没有一直死锁)
    expect(cycles).toBeGreaterThan(0)
    
  }, TEST_DURATION_MS + 5000) // 设置 Vitest 超时时间略大于测试时间
})