// frontend_2/src/tests/integration/04_trajectory.spec.ts
import { describe, it, expect, beforeAll } from 'vitest'
import { testClient, sleep, resetSystem } from '../utils'

describe('🚀 完整运镜功能集成测试 (Happy Path)', () => {
  beforeAll(async () => {
    await resetSystem()
  })

  it('F-01: 标准运镜生命周期', async () => {
    // 1. 启动
    const startRes = await testClient.post('/dynamics/identification', {
      trajectory_range: 15, trajectory_speed: 30
    })
    expect(startRes.status).toBe(200)

    // 2. 轮询
    await sleep(500)
    const statusRes = await testClient.get('/dynamics/identification/status')
    expect(statusRes.status).toBe(200)

    // 3. 停止
    const stopRes = await testClient.post('/dynamics/identification/stop')
    expect(stopRes.status).toBe(200)
  })
})